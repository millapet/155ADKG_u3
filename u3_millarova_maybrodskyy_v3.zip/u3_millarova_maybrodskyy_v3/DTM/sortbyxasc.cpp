#include "sortbyxasc.h"

sortByXAsc::sortByXAsc()
{

}
